# Effect-Baking Human Review

Unresolved decisions: **0**. These are deliberately not baked.

