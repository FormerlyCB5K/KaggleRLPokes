# Prize Check — Overview

## What this is
A self-contained module (`Ceruledge-RL/prize_check.py`) that tells the Ceruledge-RL agent which of its own cards are prized, by process of elimination, exposed as a 16-int feature vector.

## Scope (v1)
- `PrizeTracker` class: `reset()`, `update(obs, our_idx)` called every step, `vector() -> list[int]` (16 ints).
- Infers prize composition at the first full deck search (`obs.select.deck` visible).
- Automatically detects taken prizes afterward via card **serial numbers** (exact, no heuristics).
- Re-runs full elimination on every later deck search as a resync safety net.
- A smoke test (`smoke_test_prize_check.py` at repo root): unit stubs + full sim games with invariant checks.

## Explicitly out of scope
- Wiring into `features.py` / `GameStateTracker` (parked as a follow-up step).
- Opponent prize inference (we can't see their hand; different problem).
- Generality beyond the 15-unique-card Ceruledge deck (`FULL_DECK` in features.py).
- The root-level `prize_check.py` and existing `GameStateTracker.infer_prizes` are left untouched.

## Success criteria
- Before the first deck search, `vector()` returns `[0]*15 + [1]`.
- After the first search, flag = 0 and, at every subsequent step, `sum(counts) == len(ps.prize)` (remaining face-down prizes) across full simulated games.
- All counts ≥ 0 at all times; no crashes over 5+ sim games.

## Components
- `01-prize-tracker.md` — PrizeTracker behavior, state machine, elimination formula, serial-based take detection, vector format, test cases.

## Key decisions
1. New clean module in `Ceruledge-RL/`; existing implementations untouched.
2. Output is a 16-int vector: 15 per-card counts in canonical `DECK_CARDS` order + unknown flag.
3. Stateful, latching tracker; unknown only before the first deck search.
4. Prize takes detected automatically from observation deltas — upgraded during planning from id-based hand-diffing to exact serial tracking (every `Card` has a per-match unique `serial`).
5. Vector may sum to less than 6 as prizes are taken.
6. Unknown state = `[0]*15 + [1]` (zeros, not a prior).
7. Fixes a bug present in the older implementations: `preEvolution` and `tools` cards attached to in-play Pokémon are now counted as seen.

## Open questions
- None.
