"""
pokemon_encoder.py — Generalized attribute-based per-Pokemon encoding.

The deliverable: `encode_pokemon(state, is_ours, is_active, board)` returns a fixed-width
list of floats describing ANY Pokemon (not just the 5 Ceruledge-deck species) by its
attributes — type, weakness/resistance to Fire/Fighting, stage, rule, HP, retreat,
up to 2 attacks (cost + base damage + structured effect-modifier vector), keyword bags,
and a hand-computed board-realized block (hitting power, KO margins, energy deficit)
so the MLP does not have to learn KO arithmetic from raw numbers.

Design decisions (see plan / chat):
  - OUR side keeps TYPED (fire/fighting) energy costs and attached-energy counts, so the
    model can learn which energy type to attach. The OPPONENT side gets totals only —
    typed sub-fields are zeroed (we don't care what colors the opponent needs).
  - Weakness/resistance collapse to weak_to_fire / weak_to_fighting (+ resist same):
    our attackers are only ever Fire or Fighting typed.
  - Coin flips use the primitive expected-value model in effect_features.expected_heads
    (bounded "flip N coins" -> N/2 heads; unbounded "until tails" -> 1).
  - Hand-authored overrides (attack_overrides.get_override) FULLY REPLACE the generic
    CSV parse for listed card_ids.
  - Not wired into features.py / model.py yet — standalone, ready for a future MLP.

    python pokemon_encoder.py        # self-test
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

import card_data as cd
import effect_features as ef

# --- normalization constants (commensurate: HP, damage, margins all /400) --------------
MAX_HP = 400.0
MAX_DAMAGE = 400.0
MAX_RETREAT = 4.0
MAX_ENERGY = 5.0          # cost pips and attached-energy counts
MAX_DEFICIT = 5.0
RESIST = 30.0             # modern SV-era resistance is a flat -30
POISON_HP = 10.0          # between-turns poison (1 counter)
BURN_HP = 20.0            # between-turns burn (2 counters)

# Scale vars realizable from BoardContext at encode time. "heads" IS realized via
# expected_heads and discard-PILE scaling via our/opp_discard_energy (both unlike the
# fork); only within-attack discard counts ("discarded in this way") stay deferred -> 0.
_FIRE_ENERGY_ID = 2       # engine card id of Basic Fire Energy (features.py: Fire_Energy)
_FIGHTING_ENERGY_ID = 6   # engine card id of Basic Fighting Energy


@dataclass
class PokemonState:
    """Live board state of one Pokemon slot. card_id None = empty slot."""
    card_id: int | None = None
    hp_curr: int = 0
    energy_ids: list[int] = field(default_factory=list)   # attached energy card ids


@dataclass
class BoardContext:
    """The board-level context needed to realize scaling/conditional effects.
    All counts are from OUR perspective (our_* = the RL agent's side)."""
    our_active: PokemonState | None = None
    opp_active: PokemonState | None = None
    our_bench_count: int = 0
    opp_bench_count: int = 0
    our_prizes_taken: int = 0
    opp_prizes_taken: int = 0
    our_hand_count: int = 0
    opp_hand_count: int = 0
    our_conditions: int = 0     # status conditions on OUR active (poison/burn/sleep/para/conf)
    opp_conditions: int = 0
    our_tool_count: int = 0
    opp_tool_count: int = 0
    our_pokemon_count: int = 0  # active + bench
    opp_pokemon_count: int = 0
    our_discard_energy: int = 0  # energy cards in each side's discard pile
    opp_discard_energy: int = 0
    stadium_in_play: bool = False


# =======================================================================================
# Card stats resolution (override hook -> generic CSV parse)
# =======================================================================================
def _resolve_stats(card_id) -> cd.CardStats:
    """Generic CSV parse only. attack_overrides.py now carries spec-03 tag-block
    overrides (dicts, not CardStats fields) consumed by opponent_tags.py — this
    superseded encoder no longer applies them."""
    return cd.CardRegistry.load().get(card_id)


def _attached_counts(state: PokemonState) -> tuple[int, int, int]:
    """(fire, fighting, total) attached energy from raw card ids."""
    fire = sum(1 for e in state.energy_ids if e == _FIRE_ENERGY_ID)
    fighting = sum(1 for e in state.energy_ids if e == _FIGHTING_ENERGY_ID)
    return fire, fighting, len(state.energy_ids)


# =======================================================================================
# Board-realized damage (ported from the fork's derived_features.realized_damage,
# simplified to this project's fire/fighting basis + coin-flip EV)
# =======================================================================================
def _scale_count(var: str, attacker: PokemonState, attacker_is_ours: bool,
                 board: BoardContext, effect_text: str) -> float:
    """How many units the scaling variable currently counts, from BoardContext."""
    ours = attacker_is_ours
    if var == "energy":
        return float(len(attacker.energy_ids))
    if var == "benched":
        return float(board.our_bench_count if ours else board.opp_bench_count)
    if var == "heads":
        return ef.expected_heads(effect_text)
    if var == "counters":
        st = _resolve_stats(attacker.card_id)
        return max(0.0, (st.max_hp - attacker.hp_curr) / 10.0) if st.max_hp else 0.0
    if var == "pokemon":
        return float(board.our_pokemon_count if ours else board.opp_pokemon_count)
    if var == "prizes":
        return float(board.our_prizes_taken if ours else board.opp_prizes_taken)
    if var == "hand":
        return float(board.our_hand_count if ours else board.opp_hand_count)
    if var == "tools":
        return float(board.our_tool_count if ours else board.opp_tool_count)
    if var == "status":
        return float(board.opp_conditions if ours else board.our_conditions)
    if var == "discard":
        # Discard-PILE scaling ("for each Energy card in your discard pile" — Ceruledge's
        # own mechanic) is board-evaluable. Within-attack scaling ("for each card you
        # discarded in this way") is not knowable at encode time -> deferred, 0.
        if "discard pile" in (effect_text or "").lower():
            return float(board.our_discard_energy if ours else board.opp_discard_energy)
        return 0.0
    return 0.0   # anything else out of vocab -> deferred, contributes 0


def _cond_fires(cond: str, attacker: PokemonState, attacker_is_ours: bool,
                is_active: bool, defender_stats: cd.CardStats,
                board: BoardContext) -> float:
    """Probability [0,1] that a condition gate fires on this board. Deterministic gates
    return 0/1; the coin_flip gate returns its heads probability (0.5 per coin)."""
    ours = attacker_is_ours
    if cond == "coin_flip":
        return 0.5
    if cond == "target_status":
        return 1.0 if (board.opp_conditions if ours else board.our_conditions) > 0 else 0.0
    if cond == "self_status":
        mine = board.our_conditions if ours else board.opp_conditions
        return 1.0 if (mine > 0 and is_active) else 0.0
    if cond == "self_has_damage":
        st = _resolve_stats(attacker.card_id)
        return 1.0 if (st.max_hp and attacker.hp_curr < st.max_hp) else 0.0
    if cond == "target_is_ex":
        return 1.0 if (defender_stats.is_ex or defender_stats.is_mega_ex) else 0.0
    if cond == "energy_count":
        return 1.0 if len(attacker.energy_ids) >= 3 else 0.0   # coarse (threshold unparsed)
    if cond == "bench_count":
        return 1.0 if (board.our_bench_count if ours else board.opp_bench_count) > 0 else 0.0
    if cond == "stadium_in_play":
        return 1.0 if board.stadium_in_play else 0.0
    return 0.0   # target_type / out-of-vocab -> defer


def _attack_deficit(atk: cd.AttackSpec, state: PokemonState, is_ours: bool) -> float:
    """Energy still needed before this attack is payable. Our side: typed (fire/fighting
    pips need matching energy, remainder colorless-payable by anything). Opponent side:
    total-count approximation only, consistent with 'we don't track their energy types'."""
    fire, fighting, total = _attached_counts(state)
    if not is_ours:
        return max(0.0, atk.total_cost - total)
    short_fire = max(0, atk.fire_count - fire)
    short_fight = max(0, atk.fighting_count - fighting)
    colorless_need = atk.total_cost - atk.fire_count - atk.fighting_count
    leftover = total - min(fire, atk.fire_count) - min(fighting, atk.fighting_count)
    short_colorless = max(0, colorless_need - leftover)
    return float(short_fire + short_fight + short_colorless)


def _expected_damage(atk: cd.AttackSpec, attacker: PokemonState, attacker_is_ours: bool,
                     attacker_active: bool, attacker_stats: cd.CardStats,
                     defender_stats: cd.CardStats, board: BoardContext) -> float:
    """Expected HP damage of one attack vs one defender on this board: base + realized
    modifiers (coin flips as EV), then weakness x2 / resistance -30 vs the attacker's
    type — restricted to Fire/Fighting since those are the only weak/resist flags kept."""
    e = ef.parse_effect(atk.effect_text)
    dmg = float(atk.damage_base)

    if e["scale_amount"] and e["scale_var"]:
        n = _scale_count(e["scale_var"], attacker, attacker_is_ours, board, atk.effect_text)
        scaled = e["scale_amount"] * n
        # "N MORE damage for each" is additive on the base; "N damage for each" replaces it
        additive = "more damage for each" in (atk.effect_text or "").lower()
        dmg = (dmg + scaled) if additive else scaled

    if e["bonus_flat"]:
        conds = e["conditions"]
        if not conds:
            dmg += e["bonus_flat"]
        else:
            p = max(_cond_fires(c, attacker, attacker_is_ours, attacker_active,
                                defender_stats, board) for c in conds)
            dmg += e["bonus_flat"] * p

    # base damage itself gated by a coin flip with no bonus/scaling parsed
    # ("Flip a coin. If tails, this attack does nothing.")
    if "if tails, this attack does nothing" in (atk.effect_text or "").lower():
        dmg *= 0.5

    if dmg > 0:
        at = attacker_stats.type_sym
        if at == cd.FIRE_SYM:
            if defender_stats.weak_fire and "ignore_weakness" not in e["bypass"]:
                dmg *= 2.0
            if defender_stats.resist_fire and "ignore_resistance" not in e["bypass"]:
                dmg = max(0.0, dmg - RESIST)
        elif at == cd.FIGHTING_SYM:
            if defender_stats.weak_fighting and "ignore_weakness" not in e["bypass"]:
                dmg *= 2.0
            if defender_stats.resist_fighting and "ignore_resistance" not in e["bypass"]:
                dmg = max(0.0, dmg - RESIST)
    return max(0.0, dmg)


def _clamp(x, lo, hi):
    return lo if x < lo else hi if x > hi else x


# =======================================================================================
# Feature blocks
# =======================================================================================
def _identity_block(st: cd.CardStats) -> list:
    f: list = []
    # type one-hot + none (11)
    tvec = [0.0] * (len(cd.POK_TYPES) + 1)
    if st.type_sym in cd.POK_TYPES:
        tvec[cd.POK_TYPES.index(st.type_sym)] = 1.0
    else:
        tvec[-1] = 1.0
    f += tvec
    f += [1.0 if st.weak_fire else 0.0, 1.0 if st.weak_fighting else 0.0]        # 2
    f += [1.0 if st.resist_fire else 0.0, 1.0 if st.resist_fighting else 0.0]    # 2
    f += [1.0 if st.stage == s else 0.0 for s in cd.STAGES]                       # 3
    is_plain = not (st.is_ex or st.is_mega_ex)
    f += [1.0 if is_plain else 0.0, 1.0 if st.is_ex else 0.0,
          1.0 if st.is_mega_ex else 0.0]                                           # 3
    f.append(_clamp(st.max_hp / MAX_HP, 0.0, 1.0))                                 # 1
    f.append(_clamp(st.retreat / MAX_RETREAT, 0.0, 1.0))                           # 1
    return f                                                                       # 23


N_IDENTITY = 23


def _live_block(state: PokemonState, is_ours: bool) -> list:
    fire, fighting, total = _attached_counts(state)
    f = [_clamp(state.hp_curr / MAX_HP, 0.0, 1.0)]
    if is_ours:
        f += [_clamp(fire / MAX_ENERGY, 0.0, 1.0),
              _clamp(fighting / MAX_ENERGY, 0.0, 1.0)]
    else:
        f += [0.0, 0.0]
    f.append(_clamp(total / MAX_ENERGY, 0.0, 1.0))
    return f                                                                       # 4


N_LIVE = 4
N_ATTACK_SLOT = 3 + 1 + ef.MODIFIER_DIM        # cost(3) + damage(1) + modifiers(27) = 31


def _attack_block(atk: cd.AttackSpec | None, is_ours: bool) -> list:
    if atk is None:
        return [0.0] * N_ATTACK_SLOT
    if is_ours:
        f = [_clamp(atk.fire_count / MAX_ENERGY, 0.0, 1.0),
             _clamp(atk.fighting_count / MAX_ENERGY, 0.0, 1.0)]
    else:
        f = [0.0, 0.0]
    f.append(_clamp(atk.total_cost / MAX_ENERGY, 0.0, 1.0))
    f.append(_clamp(atk.damage_base / MAX_DAMAGE, 0.0, 1.0))
    f += ef.effect_vector(atk.effect_text)
    return f


N_DERIVED = 9


def _derived_block(state: PokemonState, st: cd.CardStats, is_ours: bool,
                   is_active: bool, board: BoardContext) -> list:
    """Hand-computed KO arithmetic so the MLP doesn't have to learn it."""
    defender_state = board.opp_active if is_ours else board.our_active
    defender_stats = _resolve_stats(defender_state.card_id) if defender_state else cd.CardStats()

    # attacker side: best payable attack of THIS Pokemon vs the enemy active
    hitting = 0.0
    payable_now = False
    min_deficit = None
    for atk in st.attacks:
        deficit = _attack_deficit(atk, state, is_ours)
        if min_deficit is None or deficit < min_deficit:
            min_deficit = deficit
        if deficit == 0.0:
            payable_now = True
            if defender_state is not None:
                r = _expected_damage(atk, state, is_ours, is_active, st, defender_stats, board)
                if r > hitting:
                    hitting = r
    if min_deficit is None:
        min_deficit = 0.0                      # no attacks -> nothing to power up

    if defender_state is not None and defender_state.hp_curr > 0:
        best_margin = hitting - defender_state.hp_curr
        best_lethal = 1.0 if (payable_now and hitting > 0
                              and hitting >= defender_state.hp_curr) else 0.0
    else:
        best_margin, best_lethal = 0.0, 0.0

    # defender side: best payable enemy-active attack vs THIS Pokemon (only meaningful
    # when this Pokemon is active — bench sniping is out of this approximation's scope)
    incoming = 0.0
    if is_active and defender_state is not None:
        for atk in defender_stats.attacks:
            if _attack_deficit(atk, defender_state, not is_ours) == 0.0:
                r = _expected_damage(atk, defender_state, not is_ours, True,
                                     defender_stats, st, board)
                if r > incoming:
                    incoming = r
    inc_margin = incoming - state.hp_curr
    inc_lethal = 1.0 if (incoming > 0 and incoming >= state.hp_curr) else 0.0

    # between-turns poison/burn on this side's active
    between = 0.0
    if is_active:
        n_conds = board.our_conditions if is_ours else board.opp_conditions
        if n_conds > 0:
            between = POISON_HP                # coarse: >=1 condition -> at least poison tick

    return [
        _clamp(hitting / MAX_DAMAGE, 0.0, 1.0),
        _clamp(best_margin / MAX_DAMAGE, -1.0, 1.0),
        best_lethal,
        _clamp(incoming / MAX_DAMAGE, 0.0, 1.0),
        _clamp(inc_margin / MAX_DAMAGE, -1.0, 1.0),
        inc_lethal,
        _clamp(between / MAX_DAMAGE, 0.0, 1.0),
        1.0 if payable_now else 0.0,
        _clamp(min_deficit / MAX_DEFICIT, 0.0, 1.0),
    ]


N_KEYWORDS = len(ef.EFFECT_KEYWORDS) * 2       # attack bag + ability bag = 80
POKEMON_ENCODING_DIM = (N_IDENTITY + N_LIVE + N_ATTACK_SLOT * cd.MAX_ATTACKS
                        + N_KEYWORDS + N_DERIVED)
assert POKEMON_ENCODING_DIM == 178, POKEMON_ENCODING_DIM


def encoding_schema() -> list:
    """1:1 readable labels for the encoding vector (debugging / feature inspection)."""
    out = [f"type:{t}" for t in cd.POK_TYPES] + ["type:none"]
    out += ["weak_fire", "weak_fighting", "resist_fire", "resist_fighting"]
    out += [f"stage:{s.split(' ')[0]}" for s in cd.STAGES]
    out += ["rule:plain", "rule:ex", "rule:mega_ex", "max_hp", "retreat"]
    out += ["hp_curr", "energy_fire", "energy_fighting", "energy_total"]
    for i in range(cd.MAX_ATTACKS):
        out += [f"atk{i}:cost_fire", f"atk{i}:cost_fighting", f"atk{i}:cost_total",
                f"atk{i}:damage"]
        out += [f"atk{i}:{s}" for s in ef.modifier_schema()]
    out += [f"kw_atk:{k}" for k in ef.EFFECT_KEYWORDS]
    out += [f"kw_abl:{k}" for k in ef.EFFECT_KEYWORDS]
    out += ["hitting_power", "best_ko_margin", "best_ko_lethal", "incoming_dmg",
            "incoming_ko_margin", "incoming_lethal", "between_turns", "payable_now",
            "deficit_total"]
    assert len(out) == POKEMON_ENCODING_DIM
    return out


def encode_pokemon(state: PokemonState | None, is_ours: bool, is_active: bool,
                   board: BoardContext) -> list:
    """One Pokemon slot -> POKEMON_ENCODING_DIM floats, ready for an MLP.
    Empty slot (None state or None card_id) -> all zeros."""
    if state is None or state.card_id is None:
        return [0.0] * POKEMON_ENCODING_DIM
    st = _resolve_stats(state.card_id)
    f = _identity_block(st)
    f += _live_block(state, is_ours)
    for i in range(cd.MAX_ATTACKS):
        f += _attack_block(st.attacks[i] if i < len(st.attacks) else None, is_ours)
    f += ef.keyword_union([a.effect_text for a in st.attacks])
    f += ef.keyword_union(st.abilities)
    f += _derived_block(state, st, is_ours, is_active, board)
    assert len(f) == POKEMON_ENCODING_DIM
    return f


# =======================================================================================
def _selftest():
    import math

    # empty slot -> zeros
    empty = encode_pokemon(None, True, False, BoardContext())
    assert empty == [0.0] * POKEMON_ENCODING_DIM
    assert encode_pokemon(PokemonState(card_id=None), True, False, BoardContext()) == empty
    assert len(encoding_schema()) == POKEMON_ENCODING_DIM

    # a real matchup: our Ceruledge ex (320) with 2 fire vs an opponent Pokemon
    ceruledge = PokemonState(card_id=320, hp_curr=270,
                             energy_ids=[_FIRE_ENERGY_ID, _FIRE_ENERGY_ID])
    opp = PokemonState(card_id=741, hp_curr=60, energy_ids=[])
    board = BoardContext(our_active=ceruledge, opp_active=opp,
                         our_bench_count=2, opp_bench_count=1,
                         our_pokemon_count=3, opp_pokemon_count=2,
                         our_hand_count=5, opp_hand_count=4,
                         our_discard_energy=2)   # Abyssal Flames: 30 + 20*2 = 70

    v = encode_pokemon(ceruledge, True, True, board)
    assert len(v) == POKEMON_ENCODING_DIM
    assert all(math.isfinite(x) and -1.0 <= x <= 1.0 for x in v)
    schema = encoding_schema()
    by_name = dict(zip(schema, v))
    assert by_name["rule:ex"] == 1.0
    assert by_name["type:{R}"] == 1.0
    assert by_name["energy_fire"] == 2 / MAX_ENERGY
    assert by_name["hp_curr"] == 270 / MAX_HP

    # opponent-side view of the same Pokemon: typed fields zeroed, totals kept
    v_opp = encode_pokemon(ceruledge, False, True, board)
    b2 = dict(zip(schema, v_opp))
    assert b2["energy_fire"] == 0.0 and b2["energy_fighting"] == 0.0
    assert b2["energy_total"] == 2 / MAX_ENERGY
    for i in range(cd.MAX_ATTACKS):
        assert b2[f"atk{i}:cost_fire"] == 0.0 and b2[f"atk{i}:cost_fighting"] == 0.0

    # coin-flip EV: bounded vs unbounded flips give different realized damage
    reg = cd.CardRegistry.load()
    bounded_id = unbounded_id = None
    for cid, st in reg.stats.items():
        for a in st.attacks:
            t = (a.effect_text or "").lower()
            if "damage for each heads" in t:
                if "until you get tails" in t and unbounded_id is None:
                    unbounded_id = (cid, a)
                elif "flip" in t and "until" not in t and bounded_id is None:
                    p = ef.parse_effect(a.effect_text)
                    if p["scale_var"] == "heads" and ef.expected_heads(a.effect_text) != 1.0:
                        bounded_id = (cid, a)
        if bounded_id and unbounded_id:
            break
    assert bounded_id is not None, "no bounded flip-scaling attack found in CSV"
    assert unbounded_id is not None, "no unbounded flip-scaling attack found in CSV"
    for label, (cid, atk) in (("bounded", bounded_id), ("unbounded", unbounded_id)):
        st = reg.get(cid)
        attacker = PokemonState(card_id=cid, hp_curr=st.max_hp or 100,
                                energy_ids=[_FIRE_ENERGY_ID] * atk.total_cost)
        dmg = _expected_damage(atk, attacker, True, True, st, reg.get(741), board)
        ev = ef.expected_heads(atk.effect_text)
        print(f"  {label}: card {cid} '{atk.name}' EV(heads)={ev} -> expected dmg {dmg:.0f}")
        assert dmg > 0
    assert (ef.expected_heads(bounded_id[1].effect_text)
            != ef.expected_heads(unbounded_id[1].effect_text)) or \
        bounded_id[1].effect_text != unbounded_id[1].effect_text

    # derived: our 2-energy Ceruledge should be flagged payable with positive hitting power.
    # Abyssal Flames (1 energy) with 2 discard-pile energy = 30 + 20*2 = 70 >= 60 HP -> lethal.
    assert by_name["payable_now"] == 1.0
    assert by_name["hitting_power"] == 70 / MAX_DAMAGE, by_name["hitting_power"]
    assert by_name["best_ko_lethal"] == 1.0

    # discard-pile scaling responds to the board: empty discard -> 30 damage, not lethal
    board_empty_discard = replace(board, our_discard_energy=0)
    v_ed = encode_pokemon(ceruledge, True, True, board_empty_discard)
    b_ed = dict(zip(schema, v_ed))
    assert b_ed["hitting_power"] == 30 / MAX_DAMAGE, b_ed["hitting_power"]
    assert b_ed["best_ko_lethal"] == 0.0

    # weakness realization: a fire-weak defender doubles our fire attacker's damage
    fire_weak_id = next((cid for cid, st in reg.stats.items()
                         if st.weak_fire and st.max_hp > 0), None)
    assert fire_weak_id is not None
    weak_def = PokemonState(card_id=fire_weak_id, hp_curr=reg.get(fire_weak_id).max_hp)
    board_weak = replace(board, opp_active=weak_def)
    v_weak = encode_pokemon(ceruledge, True, True, board_weak)
    b3 = dict(zip(schema, v_weak))
    assert b3["hitting_power"] >= by_name["hitting_power"], \
        (b3["hitting_power"], by_name["hitting_power"])

    print(f"pokemon_encoder self-test PASSED (dim={POKEMON_ENCODING_DIM})")


if __name__ == "__main__":
    _selftest()
